using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System;

public class RobotDogNetworkingController : MonoBehaviour
{
    [System.Serializable]
    public class LegJoint
    {
        public Transform joint;
        public float angle;
        public float lastSentAngle;
    }

    [System.Serializable]
    public class Leg
    {
        public Transform upperLeg;
        public List<LegJoint> joints;
        public float angle;
        public float lastSentAngle;
    }

    public List<Leg> legs;
    public float rotationSpeed = 1f;
    public float speedAdjustment = 0.1f;

    // Change the IP here for w/e ip your Pi has.
    private const string RASPI_IP_ADDR = "192.168.1.178";
    private const int PORT = 8888;
    private UdpClient udpClient;

    private Transform selectedTransform;
    private Vector3 lastMousePosition;

    private float sendInterval = 0.1f; // Send every 100ms
    private float lastSendTime = 0f;

    void Start()
    {
        InitializeLegs();
        InitializeNetwork();
    }

    void InitializeLegs()
    {
        foreach (var leg in legs)
        {
            leg.angle = 270f;
            leg.lastSentAngle = 270f;
            foreach (var joint in leg.joints)
            {
                joint.angle = 270f;
                joint.lastSentAngle = 270f;
            }
            leg.upperLeg.localRotation = Quaternion.Euler(leg.angle - 270f, 0f, 0f);
            foreach (var joint in leg.joints)
            {
                joint.joint.localRotation = Quaternion.Euler(joint.angle - 270f, 0f, 0f);
            }
        }
    }

    void InitializeNetwork()
    {
        udpClient = new UdpClient();
    }

    void Update()
    {
        HandleRotation();
        if (Time.time - lastSendTime > sendInterval)
        {
            if (HasNewData())
            {
                SendAngleData();
                lastSendTime = Time.time;
            }
        }
    }

    void HandleRotation()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                selectedTransform = hit.transform;
                lastMousePosition = Input.mousePosition;
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            selectedTransform = null;
        }

        if (selectedTransform != null)
        {
            Vector3 mouseDelta = Input.mousePosition - lastMousePosition;
            float rotation = mouseDelta.y * rotationSpeed * speedAdjustment;
            foreach (var leg in legs)
            {
                if (selectedTransform == leg.upperLeg)
                {
                    RotateTransform(leg.upperLeg, ref leg.angle, rotation);
                    break;
                }
                foreach (var joint in leg.joints)
                {
                    if (selectedTransform == joint.joint)
                    {
                        RotateTransform(joint.joint, ref joint.angle, rotation);
                        break;
                    }
                }
            }
            lastMousePosition = Input.mousePosition;
        }
    }

    void RotateTransform(Transform transform, ref float angle, float rotation)
    {
        angle = Mathf.Clamp(angle + rotation, 180f, 360f);
        transform.localRotation = Quaternion.Euler(angle - 270f, 0f, 0f);
    }

    bool HasNewData()
    {
        foreach (var leg in legs)
        {
            if (Mathf.Abs(leg.angle - leg.lastSentAngle) > 0.1f)
                return true;
            foreach (var joint in leg.joints)
            {
                if (Mathf.Abs(joint.angle - joint.lastSentAngle) > 0.1f)
                    return true;
            }
        }
        return false;
    }

    void SendAngleData()
    {
        List<float> angleData = new List<float>();

        foreach (Leg leg in legs)
        {
            angleData.Add(leg.angle);
            leg.lastSentAngle = leg.angle;
            foreach (LegJoint joint in leg.joints)
            {
                angleData.Add(joint.angle);
                joint.lastSentAngle = joint.angle;
            }
        }

        byte[] bytes = new byte[angleData.Count * sizeof(float)];
        Buffer.BlockCopy(angleData.ToArray(), 0, bytes, 0, bytes.Length);

        Debug.Log($"Sending {angleData.Count} angles, {bytes.Length} bytes to {RASPI_IP_ADDR}:{port}");
        Debug.Log($"Angle data: {string.Join(", ", angleData)}");
        udpClient.Send(bytes, bytes.Length, RASPI_IP_ADDR, port);
    }

    void OnApplicationQuit()
    {
        if (udpClient != null)
            udpClient.Close();
    }
}