using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System;

public class RobotDogNetworkingController : MonoBehaviour
{
    [System.Serializable]
    public class LegJoint
    {
        public Transform joint;
        public float angle;
        public float lastSentAngle;
    }

    [System.Serializable]
    public class Leg
    {
        public Transform upperLeg;
        public List<LegJoint> joints;
        public float angle;
        public float lastSentAngle;
    }
    public List<Leg> legs;
    public float rotationSpeed = 1f;
    public float speedAdjustment = 0.1f;

    public string raspiIp = "192.168.1.178";
    public int port = 8888;
    private UdpClient udpClient;

    private Transform selectedTransform;
    private Vector3 lastMousePosition;

    private float sendInterval = 0.1f;
    private float lastSendTime = 0f;
    private const float MAX_ROTATE = 60f;

    void Start()
    {
        InitializeLegs();
        InitializeNetwork();
    }

    void InitializeLegs()
    {
        foreach (var leg in legs)
        {
            leg.angle = 270f;
            leg.lastSentAngle = 270f;
            leg.upperLeg.localRotation = Quaternion.Euler(0f, 0f, 0f);
            foreach (var joint in leg.joints)
            {
                joint.angle = 270f;
                joint.lastSentAngle = 270f;
                joint.joint.localRotation = Quaternion.Euler(0f, 0f, 0f);
            }
        }
    }

    void InitializeNetwork()
    {
        udpClient = new UdpClient();
    }

    void Update()
    {
        HandleRotation();
        if (Time.time - lastSendTime > sendInterval)
        {
            if (HasNewData())
            {
                SendAngleData();
                lastSendTime = Time.time;
            }
        }
    }

    void HandleRotation()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                selectedTransform = hit.transform;
                lastMousePosition = Input.mousePosition;
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            selectedTransform = null;
        }

        if (selectedTransform != null)
        {
            Vector3 mouseDelta = Input.mousePosition - lastMousePosition;
            float rotation = mouseDelta.y * rotationSpeed * speedAdjustment;
            foreach (var leg in legs)
            {
                if (selectedTransform == leg.upperLeg)
                {
                    RotateLeg(leg, rotation);
                    break;
                }
                foreach (var joint in leg.joints)
                {
                    if (selectedTransform == joint.joint)
                    {
                        RotateJoint(joint, rotation);
                        break;
                    }
                }
            }
            lastMousePosition = Input.mousePosition;
        }
    }

    void RotateLeg(Leg leg, float rotation)
    {
        float currentAngle = leg.angle - 270f;
        float targetAngle = currentAngle + rotation;

        targetAngle = Mathf.Clamp(targetAngle, -(MAX_ROTATE), MAX_ROTATE);

        float smoothedAngle = Mathf.LerpAngle(currentAngle, targetAngle, Time.deltaTime * 100f);

        leg.angle = smoothedAngle + 270f;
        leg.upperLeg.localRotation = Quaternion.Euler(smoothedAngle, 0f, 0f);
    }

    void RotateJoint(LegJoint joint, float rotation)
    {
        float currentAngle = joint.angle - 270f;
        float targetAngle = currentAngle + rotation;

        if (rotation > 0)
        {
            targetAngle = Mathf.Clamp(targetAngle, 0f, MAX_ROTATE);
        }
        else
        {
            targetAngle = Mathf.Max(targetAngle, 0f);
        }

        float smoothedAngle = Mathf.LerpAngle(currentAngle, targetAngle, Time.deltaTime * 100f);

        joint.angle = smoothedAngle + 270f;
        joint.joint.localRotation = Quaternion.Euler(smoothedAngle, 0f, 0f);
    }

    bool HasNewData()
    {
        foreach (var leg in legs)
        {
            if (Mathf.Abs(leg.angle - leg.lastSentAngle) > 0.1f)
                return true;
            foreach (var joint in leg.joints)
            {
                if (Mathf.Abs(joint.angle - joint.lastSentAngle) > 0.1f)
                    return true;
            }
        }
        return false;
    }

    void SendAngleData()
    {
        List<float> angleData = new List<float>();

        foreach (Leg leg in legs)
        {
            float adjustedLegAngle = leg.angle - 180f;
            angleData.Add(adjustedLegAngle);
            leg.lastSentAngle = leg.angle;
            foreach (LegJoint joint in leg.joints)
            {
                float adjustedJointAngle = joint.angle - 180f;
                angleData.Add(adjustedJointAngle);
                joint.lastSentAngle = joint.angle;
            }
        }

        byte[] bytes = new byte[angleData.Count * sizeof(float)];
        Buffer.BlockCopy(angleData.ToArray(), 0, bytes, 0, bytes.Length);

        Debug.Log($"Sending {angleData.Count} angles, {bytes.Length} bytes to {raspiIp}:{port}");
        Debug.Log($"Adjusted angle data: {string.Join(", ", angleData)}");
        udpClient.Send(bytes, bytes.Length, raspiIp, port);
    }

    void OnApplicationQuit()
    {
        if (udpClient != null)
            udpClient.Close();
    }
}